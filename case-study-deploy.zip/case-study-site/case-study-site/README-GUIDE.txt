===========================================================
  CASE STUDY WEBSITE — DEPLOY & EDIT GUIDE
===========================================================

WHAT'S IN THIS FOLDER
---------------------
  index.html          <- the whole page (text + layout + styling in one file)
  images/             <- put your screenshots and gifs here
  README-GUIDE.txt    <- this file (you can delete it before deploying)

The page is plain static HTML. No build step, no software to install.
It works the same on Netlify and on GitHub Pages.


-----------------------------------------------------------
  1. ADDING YOUR IMAGES
-----------------------------------------------------------
The page already knows the FILENAME of every image it expects.
You just drop files with those exact names into the images/ folder.

  - Names are CASE-SENSITIVE and the extension matters.
    "Scrum_values.JPG" is NOT the same as "scrum_values.jpg".
    Match them exactly as listed below.
  - Until a file is present, the page shows a tidy dashed placeholder
    box with the filename in it. So you can deploy right away and add
    images later — nothing breaks, each image just appears once added.
  - Any proportion is fine. Each image displays at its own natural
    shape, capped to a readable width. No resizing or cropping needed.
  - GIFs work too: save them with the same name but a .gif extension
    and update the filename in index.html (see section 2).

THE 18 IMAGE FILENAMES THIS PAGE EXPECTS
(in the order they appear on the page):

  Challenge 1 — SME collaboration
    Scrum_values.JPG

  Challenge 2 — Knowledge elicitation
    Selection_of_options.jpg

  Challenge 3 — Methodological
    Watch.JPG
    Scenario_choice.JPG
    Scenario_outcome_vide_call.JPG
    Scrum_values_positive_feedback.JPG
    Scrum_values_negative_feedback.JPG

  Challenge 4 — Technical
    JavaScript_1.JPG
    JavaScript_2.JPG
    Signals_learner_data.JPG
    team_call.JPG
    Scenario_outcome_vide_call.JPG   (same file as in Challenge 3 — one copy is enough)
    DaVinci_Resolve.JPG
    DaVinci_Resolve_2.JPG
    Click_to_start.JPG
    Think_together_1.JPG
    Think_together_2.JPG
    Think_together_3.JPG
    Think_together_4.JPG

Tip: open index.html in a browser (double-click it) after adding images
to check them locally before you deploy. No internet needed for that.


-----------------------------------------------------------
  2. EDITING THE TEXT LATER
-----------------------------------------------------------
Open index.html in any plain text editor (Notepad is fine; Notepad++,
VS Code, or Sublime are nicer because they colour the code).

The page is laid out top to bottom in the same order you see it on screen,
with clear comment markers you can search for:

    <!-- ===================== HERO ===================== -->
    <!-- ===================== BRIEF ===================== -->
    <!-- ===================== CHALLENGES ===================== -->
    <!-- ===================== REFLECTION ===================== -->
    <!-- ===================== FOOTER ===================== -->

HOW TO FIND AND CHANGE A PIECE OF TEXT
  - Use your editor's Find (Ctrl+F) and search for a few words of the
    sentence you want to change — e.g. search "high-performing team".
  - The words you read on the page sit between HTML tags, like:
        <h1>Towards a high-performing team</h1>
    Change only the words BETWEEN the > and < . Leave the tags alone:
        <h1>Your new title here</h1>

COMMON EDITS
  - Page title shown in the browser tab: search  <title>
  - Main headline:                      search  <h1>
  - A challenge's card title:           search  <h3>  (there are 4)
  - The short card summary:             look for  class="teaser"
  - The full report text:               the paragraphs (<p>...</p>)
                                        inside  class="report"
  - Changing a link (Netlify/LinkedIn): search for the old URL and
    replace it; it appears in the hero button AND in the footer.

RULES OF THUMB (so you don't break the layout)
  - Every opening tag like <p> needs its closing tag </p>. Keep both.
  - To start a new paragraph, copy a whole  <p>...</p>  line and edit it.
  - Don't touch anything inside the <style> block at the very top unless
    you want to change colours/spacing — that's the design, not the text.
  - Straight quotes " and apostrophes ' are fine. If you paste from Word,
    watch for "smart quotes" — they usually work, but if a stray symbol
    appears, retype that quote.
  - Save the file as plain .html (not .txt, not .docx).

After any edit: re-upload the changed index.html to your host (section 3).


-----------------------------------------------------------
  3. DEPLOYING
-----------------------------------------------------------

OPTION A — NETLIFY (easiest, no account steps beyond signup)
  1. Go to  https://app.netlify.com/drop
  2. Drag this whole folder (the one containing index.html and images/)
     onto the drop zone.
  3. It goes live in a few seconds and gives you a URL.
  4. To update later: drag the folder again (or set up "deploys" from a
     folder). You can also rename the site to something tidier in
     Site settings -> Change site name.

OPTION B — GITHUB PAGES
  1. Create a new repository on GitHub (public).
  2. Upload index.html and the images/ folder to it (Add file ->
     Upload files, drag them in, Commit).
  3. Repo -> Settings -> Pages.
  4. Under "Build and deployment", Source = "Deploy from a branch",
     Branch = main, Folder = / (root). Save.
  5. Wait ~1 minute. The page appears at:
        https://YOUR-USERNAME.github.io/REPO-NAME/
  6. To update later: upload the changed file(s) to the repo again.

  NOTE: GitHub Pages REQUIRES the homepage file to be named exactly
  index.html — which it already is. Don't rename it.


-----------------------------------------------------------
  4. THE LINK FOR LINKEDIN
-----------------------------------------------------------
Once deployed, the URL from Netlify or GitHub Pages is what you paste
into your LinkedIn post / profile. The page is public and needs no login.

The "Try the live module" button at the top and the footer link both
point to your Netlify module:
    https://gleeful-rabanadas-7a81ef.netlify.app/
If that module URL ever changes, update it in index.html (section 2).
